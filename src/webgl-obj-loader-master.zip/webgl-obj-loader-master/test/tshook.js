require("ts-node").register({
    project: "test/tsconfig.json",
});